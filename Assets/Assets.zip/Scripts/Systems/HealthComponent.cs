using UnityEngine;

public class HealthComponent : MonoBehaviour
{
    public int Health { get; private set; }
    public int MaxHealth { get; private set; }
    public GameObject obj { get; private set; }


    private void Awake()
    {
        Initialize(100);
    }

    public void Initialize(int maxHealth = 100)
    {
        Health = maxHealth;
        MaxHealth = maxHealth;
    }

    public void TakeDamage(int amount = 1)
    {
        int result = Health - amount;
        Health = (result < 0) ? 0 : result;
        // if(IsDead()) { Die(); }
    }

    public void Heal(int amount = 1)
    {
        int result = Health + amount;
        Health = (result > MaxHealth) ? MaxHealth : result;
    }

    public bool IsDead() => Health == 0;

    public void Die() => GameObject.Destroy(gameObject);
}